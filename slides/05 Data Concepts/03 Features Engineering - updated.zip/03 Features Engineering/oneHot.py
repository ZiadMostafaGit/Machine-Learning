
def pandas_one_hot():
    import pandas as pd

    train_df = pd.DataFrame({'Letter': ['a', 'b', 'a', 'c']})
    print(pd.get_dummies(train_df))
    '''
       Letter_a  Letter_b  Letter_c
0         1         0         0
1         0         1         0
2         1         0         0
    '''
    # test might have LESS or more types
    test_df = pd.DataFrame({'Letter': ['c', 'a']})
    print(pd.get_dummies(test_df))
    '''
   Letter_a  Letter_c
0         0         1
1         1         0
    '''

def sklean_onehot():
    from sklearn.preprocessing import OneHotEncoder
    enc = OneHotEncoder(handle_unknown='ignore')
    #enc = OneHotEncoder(handle_unknown='error')

    # 3 examples, 4 features
    X = [['Male', 100, 20.5, 'red'], ['Female', 3, 12, 'green'],
         ['Female', 225, 20.5, 'red']]
    enc.fit(X)

    categores = enc.categories_    # 4 lists of features
    '''
    [
    array(['Female', 'Male'], dtype=object), 
    array([3, 100, 225], dtype=object), 
    array([12, 20.5], dtype=object), 
    array(['green', 'red'], dtype=object)]
    '''

    X[1][0] = 'NA'  # test unknown features: assign 0
    X = enc.transform(X).toarray()
    print(X)
    '''
    ['Male', 100, 20.5, 'red']
        Male:   index is 1 out of 2: 0 1
        100:    index is 1 out of 3: 0 1 0
        20.5:   index is 1 out of 2: 0 1
        red:    index is 1 out of 2: 0 1
        Total:  0 1 0 1 0 0 1 0 1

    [[0. 1. 0. 1. 0. 0. 1. 0. 1.]
     [0. 0. 1. 0. 0. 1. 0. 1. 0.]
     [1. 0. 0. 0. 1. 0. 1. 0. 1.]]
    '''


if __name__ == '__main__':
    sklean_onehot()


