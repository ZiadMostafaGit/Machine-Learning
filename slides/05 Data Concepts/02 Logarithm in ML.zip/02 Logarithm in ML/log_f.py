import numpy as np
import matplotlib.pyplot as plt
import math
import numpy as np
from scipy.stats import lognorm


def visualize2D(x, y, is_scatter=True, tite='x vs y'):
    if is_scatter:
        plt.scatter(x, y)
    else:
        plt.plot(x, y)
    plt.title(tite)
    plt.xlabel('x')
    plt.ylabel('log10 (y)')

    plt.xticks(x)
    plt.yticks(y)

    plt.grid()
    plt.show()


def lognorm():
    def histogram_vis(x, title):
        n, bins, patches = plt.hist(x, 20, density=True, facecolor='g', alpha=0.75, edgecolor='black')

        plt.xlabel('x')
        plt.ylabel('y')
        plt.title(title)
        plt.grid(True)
        plt.show()

    lognorm_values = lognorm.rvs(s=1, scale=math.exp(1), size=1000)

    histogram_vis(lognorm_values, title = 'Lognorm')
    histogram_vis(np.log(lognorm_values), title='Normal')


def vis_scale():
    plt.axes()
    plt.xlabel('x')
    plt.yticks(np.arange(0, 100, 10))
    plt.xticks(np.arange(0, 10, 1))      # additive scale 1
    #plt.xticks(2 ** np.arange(0, 6, 1))     # multiplicative scale 2
    plt.show()


def effect_of_log():

    x = np.arange(0, 15, 1)
    #y = 2 ** x
    #y = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]
    y = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 600, 650, 2048, 4096, 8192]
    y = np.log2(y)
    x += 2008
    visualize2D(x, y, is_scatter=False, tite='x vs log10(y)')


def question():

    x = np.array([100, 200, 300, 400])
    y = np.array([1.0/1000, 1.0/100000, 10000, 1.0/100000])
    y = np.log10(y)
    visualize2D(x, y, is_scatter=False)


if __name__ == '__main__':
    effect_of_log()
