from sklearn.preprocessing import PolynomialFeatures

import numpy as np

poly = PolynomialFeatures(degree=2,
                          include_bias = False)
for sz in [1, 2, 10, 100, 200, 500,
           1000, 3000, 5000, 10000]:
    x1 = np.zeros((1, sz))
    x2 = poly.fit_transform(x1)
    print(f'{sz} => {x2.shape[1]}')
